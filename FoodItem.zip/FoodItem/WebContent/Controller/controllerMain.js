///------add------
$(document).on("click", "#btnSave", function()
{
	var result= isValidFormItem();
	if(result=="true"){
		$("#formItem").submit();
	}
	else{
		$("#ViewItem").html(result);
	}
});

//----edit---
$(document).on("click", "#btnEdit", function()
{
			$("#hidMode").val("update");
			$("#itemID").val($(this).attr("param"));
			$("#itemname").val($(this).closet("tr").find('td:eq(1)').text());
			$("#price").val($(this).closet("tr").find('td:eq(2)').text());
			$("#stock").val($(this).closet("tr").find('td:eq(3)').text());
			$("#desc").val($(this).closet("tr").find('td:eq(4)').text());
});


//-------remove------
$(document).on("click", "#btnRemove", function()
		{
			var result= confirm("Are you sure?");
			$("#hidMode").val("remove");
			$("#itemID").val($(this).attr("param"));
			if(result=="true"){
				$("#formItem").submit();
			}
			else{
				$("#divStsMsgItem").html(result);
			}
		});