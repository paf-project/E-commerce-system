function emptyCheck(name, id) {
	var inputValue = document.getElementById(name);
	if (inputValue.value == "" || inputValue.value == null
			|| inputValue.value == " ") {
		id.style.backgroundColor = "lightblue";
	} else {
		id.style.backgroundColor = "";
	}
}


function validateForm() {
	var itemname = document.getElementById('itemname');
	var price = document.getElementById('price');
	var stock = document.getElementById('stock');
	var desc = document.getElementById('desc');
	
}